CREATE FUNCTION st_overlaps (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Overlaps($1,$2)
$$
