CREATE FUNCTION _st_within (rast1 raster, nband1 integer, rast2 raster, nband2 integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT _st_contains($3, $4, $1, $2) 
$$
