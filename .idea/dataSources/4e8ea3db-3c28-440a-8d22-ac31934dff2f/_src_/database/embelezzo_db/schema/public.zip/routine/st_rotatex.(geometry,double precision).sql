CREATE FUNCTION st_rotatex (geometry, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_Affine($1, 1, 0, 0, 0, cos($2), -sin($2), 0, sin($2), cos($2), 0, 0, 0)
$$
