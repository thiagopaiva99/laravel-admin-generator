CREATE FUNCTION st_envelope (raster) RETURNS geometry
	LANGUAGE sql
AS $$
select st_envelope(st_convexhull($1))
$$
