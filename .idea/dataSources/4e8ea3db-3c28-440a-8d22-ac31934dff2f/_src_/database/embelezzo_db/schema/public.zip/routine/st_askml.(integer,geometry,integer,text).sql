CREATE FUNCTION st_askml (version integer, geom geometry, maxdecimaldigits integer DEFAULT 15, nprefix text DEFAULT NULL::text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT _ST_AsKML($1, ST_Transform($2,4326), $3, $4); 
$$
