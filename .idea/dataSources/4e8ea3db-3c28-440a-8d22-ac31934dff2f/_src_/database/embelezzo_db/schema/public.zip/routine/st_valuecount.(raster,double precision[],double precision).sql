CREATE FUNCTION st_valuecount (rast raster, searchvalues double precision[], roundto double precision DEFAULT 0, OUT value double precision, OUT count integer) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT value, count FROM _st_valuecount($1, 1, TRUE, $2, $3) 
$$
