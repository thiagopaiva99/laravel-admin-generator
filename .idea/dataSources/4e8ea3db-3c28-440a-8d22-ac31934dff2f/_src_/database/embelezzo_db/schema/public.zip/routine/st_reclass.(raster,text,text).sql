CREATE FUNCTION st_reclass (rast raster, reclassexpr text, pixeltype text) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_reclass($1, ROW(1, $2, $3, NULL)) 
$$
