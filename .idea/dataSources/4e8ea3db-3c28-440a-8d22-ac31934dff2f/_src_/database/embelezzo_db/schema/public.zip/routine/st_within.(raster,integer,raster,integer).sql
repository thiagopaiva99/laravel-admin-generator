CREATE FUNCTION st_within (rast1 raster, nband1 integer, rast2 raster, nband2 integer) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT $1 && $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN _st_within(st_convexhull($1), st_convexhull($3)) ELSE _st_contains($3, $4, $1, $2) END 
$$
