CREATE FUNCTION st_value (rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT st_value($1, 1, $2, $3) 
$$
