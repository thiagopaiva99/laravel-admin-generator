CREATE FUNCTION st_intersects (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Intersects($1,$2)
$$
