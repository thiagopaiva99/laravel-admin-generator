CREATE FUNCTION st_scale (geometry, double precision, double precision, double precision) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT ST_Affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)
$$
