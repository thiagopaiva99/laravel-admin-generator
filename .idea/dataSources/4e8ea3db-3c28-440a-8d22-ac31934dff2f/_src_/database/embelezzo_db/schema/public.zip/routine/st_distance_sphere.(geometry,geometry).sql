CREATE FUNCTION st_distance_sphere (geom1 geometry, geom2 geometry) RETURNS double precision
	LANGUAGE sql
AS $$
	select st_distance(geography($1),geography($2),false)
	
$$
