CREATE FUNCTION st_quantile (rastertable text, rastercolumn text, exclude_nodata_value boolean, quantile double precision DEFAULT NULL::double precision) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT (_st_quantile($1, $2, 1, $3, 1, ARRAY[$4]::double precision[])).value 
$$
