CREATE FUNCTION st_band (rast raster, nbands text, delimiter character DEFAULT ','::bpchar) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_band($1, regexp_split_to_array(regexp_replace($2, '[[:space:]]', '', 'g'), $3)::int[]) 
$$
