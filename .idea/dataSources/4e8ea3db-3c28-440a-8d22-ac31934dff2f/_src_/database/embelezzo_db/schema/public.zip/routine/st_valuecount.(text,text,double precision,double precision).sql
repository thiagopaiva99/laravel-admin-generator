CREATE FUNCTION st_valuecount (rastertable text, rastercolumn text, searchvalue double precision, roundto double precision DEFAULT 0) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT (_st_valuecount($1, $2, 1, TRUE, ARRAY[$3]::double precision[], $4)).count 
$$
