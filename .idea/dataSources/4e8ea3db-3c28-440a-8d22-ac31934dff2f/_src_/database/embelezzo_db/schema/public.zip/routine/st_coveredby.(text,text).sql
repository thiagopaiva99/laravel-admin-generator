CREATE FUNCTION st_coveredby (text, text) RETURNS boolean
	LANGUAGE sql
AS $$
 SELECT ST_CoveredBy($1::geometry, $2::geometry);  
$$
