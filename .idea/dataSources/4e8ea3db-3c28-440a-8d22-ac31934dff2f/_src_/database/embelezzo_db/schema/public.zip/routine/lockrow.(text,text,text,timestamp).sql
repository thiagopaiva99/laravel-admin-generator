CREATE FUNCTION lockrow (text, text, text, timestamp without time zone) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT LockRow(current_schema(), $1, $2, $3, $4); 
$$
