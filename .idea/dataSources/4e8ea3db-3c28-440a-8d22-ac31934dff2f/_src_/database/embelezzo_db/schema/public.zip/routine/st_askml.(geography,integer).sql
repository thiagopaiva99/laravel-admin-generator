CREATE FUNCTION st_askml (geog geography, maxdecimaldigits integer DEFAULT 15) RETURNS text
	LANGUAGE sql
AS $$
SELECT _ST_AsKML(2, $1, $2, null)
$$
