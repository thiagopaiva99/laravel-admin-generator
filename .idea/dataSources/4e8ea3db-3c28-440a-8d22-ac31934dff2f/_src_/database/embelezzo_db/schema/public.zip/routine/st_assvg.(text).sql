CREATE FUNCTION st_assvg (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT ST_AsSVG($1::geometry,0,15);  
$$
