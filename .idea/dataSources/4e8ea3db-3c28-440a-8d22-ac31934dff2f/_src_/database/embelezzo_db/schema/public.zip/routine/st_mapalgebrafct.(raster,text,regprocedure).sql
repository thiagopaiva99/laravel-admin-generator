CREATE FUNCTION st_mapalgebrafct (rast raster, pixeltype text, onerastuserfunc regprocedure) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT st_mapalgebrafct($1, 1, $2, $3, NULL) 
$$
