CREATE FUNCTION st_approxsummarystats (rast raster, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) RETURNS record
	LANGUAGE sql
AS $$
 SELECT _st_summarystats($1, 1, TRUE, $2) 
$$
