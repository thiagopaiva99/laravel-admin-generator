CREATE FUNCTION st_touches (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 && $2 AND _ST_Touches($1,$2)
$$
