



<table width="700" align="center">
	<tr>
		<td style="border-bottom:5px solid #1BAB7D; padding:10px;" align="left" colspan="2">
			<img src="http://drsaude.aioria.com.br/assets/site/images/logo_header.png" />
		</td>
	</tr>
	<tr>
		<td align="center" style="font-size:14px;" colspan="2">

        @yield('conteudo')
			

		</td>
	</tr>
	<tr>
		<td bgcolor="#1BAB7D" align="center" style="padding:10px;">
		<br />
			<a href="http://www.docsaude.com" style="color:#FFFFFF; float:left;">www.docsaude.com</a>
			<div style="float:right">
				<a href=""><img src="http://drsaude.aioria.com.br/assets/site/images/ico-face.png"></a>
				<a href=""><img src="http://drsaude.aioria.com.br/assets/site/images/ico-link.png"></a>
				<a href=""><img src="http://drsaude.aioria.com.br/assets/site/images/ico-twitter.png"></a>
				<a href=""><img src="http://drsaude.aioria.com.br/assets/site/images/ico-insta.png"></a>
				<a href=""><img src="http://drsaude.aioria.com.br/assets/site/images/ico-whats.png"></a>
			</div>
		</td>
	</tr>
</table>

