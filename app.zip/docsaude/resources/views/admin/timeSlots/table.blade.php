{!! $dataTable->table(['width' => '100%']) !!}

