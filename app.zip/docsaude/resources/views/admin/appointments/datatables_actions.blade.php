<div class='btn-group'>
    <a href="{{ route('admin.appointments.show', $id) }}" class='btn btn-default btn-xs' data-toggle="tooltip" data-placement="top" title="Ver detalhes">
        <i class="fa fa-eye"></i> Detalhes
    </a>
</div>
