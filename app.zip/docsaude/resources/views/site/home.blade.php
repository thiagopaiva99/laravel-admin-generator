@extends('site.basic')

@section('content')

    @include('site.home.featured')

    @include('site.home.app')

    @include('site.home.download')

    @include('site.home.specialties')

@endsection