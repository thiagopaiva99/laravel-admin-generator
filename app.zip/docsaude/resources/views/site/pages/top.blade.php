<div class="pagetop">
    <div class="container">
        <span>{!! isset($title) && isset($title['small']) ? $title['small'] : "" !!}</span>
        <h1>{!! isset($title) && isset($title['big']) ? $title['big'] : "" !!}</h1>
    </div>
</div>