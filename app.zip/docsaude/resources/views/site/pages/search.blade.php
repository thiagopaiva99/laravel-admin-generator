@extends('site.page')

@section('page.content')

    @include('site.pages.searchform')

@stop